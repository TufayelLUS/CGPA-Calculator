﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CGPA_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f = new Form2();
            f.init(Convert.ToInt32(txtSubject.Text), Convert.ToInt32(txtCredit.Text));
            f.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is a CGPA Calculator for calculating CGPA using GUI interface!");
        }
    }
}
