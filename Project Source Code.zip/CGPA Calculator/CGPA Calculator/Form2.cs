﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CGPA_Calculator
{
    public partial class Form2 : Form
    {
        int numSub=0, totCredit=0, entryTot = 0;
        double result = 0.00;
        public void init(int n, int c)
        {
            numSub = n;
            totCredit = c;
        }
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void lstData_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            result = result + Convert.ToDouble(Convert.ToDouble(txtGPA.Text) * Convert.ToInt32(txtCredit.Text));
            entryTot += Convert.ToInt32(txtCredit.Text);
            if (entryTot == totCredit)
            {
                resultOut.Text = Convert.ToString(result / totCredit);
                if (resultOut.Text.Length > 5) resultOut.Text = resultOut.Text.Substring(0, 5);
                MessageBox.Show("Your CGPA is " + resultOut.Text + "!");
            }
            else if(entryTot > totCredit)
            {
                MessageBox.Show("You cannot add more data! Check your CGPA in the bottom right corner!");
                txtCredit.Text = String.Empty;
                txtGPA.Text = String.Empty;
                txtSub.Text = String.Empty;
                return;
            }
            lstData.Items.Add(txtSub.Text + " (" + txtGPA.Text + ") - " + txtCredit.Text);
            txtCredit.Text = String.Empty;
            txtGPA.Text = String.Empty;
            txtSub.Text = String.Empty;
        }

        private void txtSub_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
